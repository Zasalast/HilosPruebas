package Parcial3Poe24022021;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static java.awt.Color.green;

public class VentanaSeleccionarNivel extends JFrame implements ActionListener {

    PanelControlVentanaParcial3 jp_Panel_controles;
    PanelPrincipalParcial3 jp_principal;
    JButton btn_inicio, bn_sad, btn_siguente_pregunta, bn_sorprendido, Terminar, Limpiar;

    public VentanaSeleccionarNivel(String title, int ancho, int alto, boolean bloqueo_ventana, boolean Visible_ventana) throws HeadlessException {
        super(title);
        setLayout(new BorderLayout(2, 2));
        setSize(ancho + 10, alto + 40);//ancho , alto
        setBackground(Color.GRAY);///color fondo
        setLocationRelativeTo(null);//centro de pantallla
        setResizable(bloqueo_ventana);//cambiar tamaño de pantalla
        setDefaultCloseOperation(EXIT_ON_CLOSE);
       jp_Panel_controles = new PanelControlVentanaParcial3("Seleccione el nivel");
        components();
        jp_principal = new PanelPrincipalParcial3();
        PanelBorderLAyout();
        this.setVisible(Visible_ventana);
    }

    void components() {
        btn_inicio = new JButton("Nivel1");
        btn_inicio.addActionListener(this);
        jp_Panel_controles.AddComponentes(btn_inicio);

        btn_siguente_pregunta = new JButton("Nivel 2");
        btn_siguente_pregunta.addActionListener(this);
        jp_Panel_controles.AddComponentes(btn_siguente_pregunta);

        Terminar = new JButton("Nivel 3");
        Terminar.addActionListener(this);
        jp_Panel_controles.AddComponentes(Terminar);
    }
    public void PanelBorderLAyout() {
        jp_principal.addJPanel(jp_Panel_controles.componente(), BorderLayout.PAGE_START);
               this.add(jp_principal);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn_inicio) {
            VentanaPrincipalParcial v1 = new VentanaPrincipalParcial("Parcial 3", 600, 200, false, true);
        }
    }
}