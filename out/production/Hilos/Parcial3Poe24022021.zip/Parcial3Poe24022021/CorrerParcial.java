package Parcial3Poe24022021;

public class CorrerParcial {
    public static void main(String[] args) {
        VentanaSeleccionarNivel v1 = new VentanaSeleccionarNivel("Parcial 3", 300, 40, false, true);

    }
    }
